#ifndef CONFIG_H
#define CONFIG_H

#define RFS_DEFAULT_IP   "127.0.0.1"
#define RFS_DEFAULT_PORT 2000
#define RFS_ROOT "rfsroot"

#endif
